<?php
class TesteService
{
    public function executa($param)
    {
        var_dump($param);
    }
}