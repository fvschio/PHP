<?php
return [
    'host'  =>  "",
    'port'  =>  "",
    'name'  =>  "app/database/curso.db",
    'user'  =>  "",
    'pass'  =>  "",
    'type'  =>  "sqlite",
    'prep'  =>  "1"
];